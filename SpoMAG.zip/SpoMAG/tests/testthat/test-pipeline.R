test_that("Pipeline funciona para esporulante e asporogênico", {
  # Caminhos
  file_spor <- system.file("extdata", "sporulating.csv", package = "SpoMAG")
  file_aspo <- system.file("extdata", "asporogenic.csv", package = "SpoMAG")

  # Leitura dos dados
  df_spor <- readr::read_csv(file_spor)
  df_aspo <- readr::read_csv(file_aspo)

  # Aplicando funções
  filtered_spor <- sporulation_gene_name(df_spor)
  filtered_aspo <- sporulation_gene_name(df_aspo)

  bin_spor <- build_binary_matrix(filtered_spor)
  bin_aspo <- build_binary_matrix(filtered_aspo)

  # Carregando modelo salvo (precisa estar acessível no teste!)
  modelo_path <- system.file("extdata", "modelos_stacking2.RData", package = "SpoMAG")
  if (file.exists(modelo_path)) {
    result_spor <- predict_sporulation(bin_spor, modelo_path)
    result_aspo <- predict_sporulation(bin_aspo, modelo_path)

    # Testa se as colunas esperadas foram criadas
    expect_true(all(c("Meta_Prediction", "Meta_Prob_Esporulante") %in% colnames(result_spor)))
    expect_true(all(c("Meta_Prediction", "Meta_Prob_Esporulante") %in% colnames(result_aspo)))
  } else {
    warning("Modelo de predição não disponível para teste.")
  }
})
